package com.dicoding.picodiploma.loginwithanimation.data.model

data class RegisterResponse(
    val error: Boolean,
    val message: String
)